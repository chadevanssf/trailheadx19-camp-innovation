(function (Engine) {
  'use strict';

  const proto = {
    add(className) {
      if (typeof className === 'string') {
        this[className] = true;
      } else {
        Object.assign(this, className);
      }

      return this;
    },

    invert() {
      Object.keys(this).forEach(key => {
        this[key] = !this[key];
      });
      return this;
    },

    toString() {
      return Object.keys(this).filter(key => this[key]).join(' ');
    }

  };
  function classSet(config) {
    if (typeof config === 'string') {
      const key = config;
      config = {};
      config[key] = true;
    }

    return Object.assign(Object.create(proto), config);
  }

  function assert(condition, message) {
    if (process.env.NODE_ENV !== 'production') {
      if (!condition) {
        throw new Error(message);
      }
    }
  }

  /**
   * Utility function to generate an unique guid.
   * used on state objects to provide a performance aid when iterating
   * through the items and marking them for render
   * @returns {String} an unique string ID
   */
  function guid() {
    function s4() {
      return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    }

    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  }

  function classListMutation(classList, config) {
    Object.keys(config).forEach(key => {
      if (typeof key === 'string' && key.length) {
        if (config[key]) {
          classList.add(key);
        } else {
          classList.remove(key);
        }
      }
    });
  }

  /**
  A string normalization utility for attributes.
  @param {String} value - The value to normalize.
  @param {Object} config - The optional configuration object.
  @param {String} [config.fallbackValue] - The optional fallback value to use if the given value is not provided or invalid. Defaults to an empty string.
  @param {Array} [config.validValues] - An optional array of valid values. Assumes all input is valid if not provided.
  @return {String} - The normalized value.
  **/
  function normalizeString(value, config = {}) {
    const {
      fallbackValue = '',
      validValues
    } = config;
    let normalized = typeof value === 'string' && value.trim() || '';
    normalized = normalized.toLowerCase();

    if (validValues && validValues.indexOf(normalized) === -1) {
      normalized = fallbackValue;
    }

    return normalized;
  }
  /**
  A boolean normalization utility for attributes.
  @param {Any} value - The value to normalize.
  @return {Boolean} - The normalized value.
  **/

  function normalizeBoolean(value) {
    return typeof value === 'string' || !!value;
  }

  const keyCodes = {
    tab: 9,
    backspace: 8,
    enter: 13,
    escape: 27,
    space: 32,
    pageup: 33,
    pagedown: 34,
    end: 35,
    home: 36,
    left: 37,
    up: 38,
    right: 39,
    down: 40,
    delete: 46,
    shift: 16
  };

  const isIE11 = isIE11Test(navigator);
  const isChrome = isChromeTest(navigator); // The following functions are for tests only

  function isIE11Test(navigator) {
    // https://stackoverflow.com/questions/17447373/how-can-i-target-only-internet-explorer-11-with-javascript
    return /Trident.*rv[ :]*11\./.test(navigator.userAgent);
  }
  function isChromeTest(navigator) {
    // https://stackoverflow.com/questions/4565112/javascript-how-to-find-out-if-the-user-browser-is-chrome
    return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
  }

  /* eslint eslint-comments/no-use: off */

  /* eslint-disable lwc/no-aura */
  const FUNCTION = 'function';

  function getConfigFromAura($A) {
    return {
      getFormFactor() {
        return $A.get('$Browser.formFactor');
      },

      getLocale() {
        return $A.get('$Locale');
      },

      getLocalizationService() {
        return $A.localizationService;
      },

      getPathPrefix() {
        return $A.getContext().getPathPrefix();
      },

      getToken(name) {
        return $A.getToken(name);
      },

      sanitizeDOM(dirty, config) {
        return $A.util.sanitizeDOM(dirty, config);
      }

    };
  }

  function createStandAloneConfig() {
    return {
      getFormFactor() {
        return 'DESKTOP';
      },

      getLocale() {
        return {
          userLocaleLang: 'en',
          userLocaleCountry: 'US',
          language: 'en',
          country: 'US',
          variant: '',
          langLocale: 'en_US',
          nameOfMonths: [{
            fullName: 'January',
            shortName: 'Jan'
          }, {
            fullName: 'February',
            shortName: 'Feb'
          }, {
            fullName: 'March',
            shortName: 'Mar'
          }, {
            fullName: 'April',
            shortName: 'Apr'
          }, {
            fullName: 'May',
            shortName: 'May'
          }, {
            fullName: 'June',
            shortName: 'Jun'
          }, {
            fullName: 'July',
            shortName: 'Jul'
          }, {
            fullName: 'August',
            shortName: 'Aug'
          }, {
            fullName: 'September',
            shortName: 'Sep'
          }, {
            fullName: 'October',
            shortName: 'Oct'
          }, {
            fullName: 'November',
            shortName: 'Nov'
          }, {
            fullName: 'December',
            shortName: 'Dec'
          }, {
            fullName: '',
            shortName: ''
          }],
          nameOfWeekdays: [{
            fullName: 'Sunday',
            shortName: 'SUN'
          }, {
            fullName: 'Monday',
            shortName: 'MON'
          }, {
            fullName: 'Tuesday',
            shortName: 'TUE'
          }, {
            fullName: 'Wednesday',
            shortName: 'WED'
          }, {
            fullName: 'Thursday',
            shortName: 'THU'
          }, {
            fullName: 'Friday',
            shortName: 'FRI'
          }, {
            fullName: 'Saturday',
            shortName: 'SAT'
          }],
          labelForToday: 'Today',
          firstDayOfWeek: 1,
          timezone: 'America/Los_Angeles',
          isEasternNameStyle: false,
          dateFormat: 'MMM d, yyyy',
          datetimeFormat: 'MMM d, yyyy h:mm:ss a',
          timeFormat: 'h:mm:ss a',
          numberFormat: '#,##0.###',
          decimal: '.',
          grouping: ',',
          zero: '0',
          percentFormat: '#,##0%',
          currencyFormat: '¤ #,##0.00;¤-#,##0.00',
          currencyCode: 'USD',
          currency: '$',
          dir: 'ltr'
        };
      },

      getLocalizationService() {
        const pad = n => {
          return n < 10 ? '0' + n : n;
        };

        const doublePad = n => {
          return n < 10 ? '00' + n : n < 100 ? '0' + n : n;
        };

        return {
          parseDateTime(dateString) {
            if (!dateString) {
              return null;
            }

            return new Date(dateString);
          },

          parseDateTimeUTC(dateString) {
            if (!dateString) {
              return null;
            }

            return new Date(dateString);
          },

          parseDateTimeISO8601(dateString) {
            // If input is time only
            if (!dateString.includes('-')) {
              dateString = '2014-03-20T' + dateString;
            }

            return new Date(dateString);
          },

          formatDate(date) {
            return date.toISOString().split('T')[0];
          },

          formatDateUTC(date) {
            return this.formatDate(date);
          },

          formatTime(date) {
            return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${doublePad(date.getMilliseconds())}`;
          },

          isBefore(date1, date2) {
            const hasValidArguments = date1 && date2 && typeof date1.getTime === FUNCTION && typeof date2.getTime === FUNCTION;
            return hasValidArguments && date1.getTime() < date2.getTime();
          },

          isAfter(date1, date2) {
            const hasValidArguments = date1 && date2 && typeof date1.getTime === FUNCTION && typeof date2.getTime === FUNCTION;
            return hasValidArguments && date1.getTime() > date2.getTime();
          },

          isSame(date1, date2) {
            const hasValidArguments = date1 && date2 && typeof date1.getTime === FUNCTION && typeof date2.getTime === FUNCTION;
            return hasValidArguments && date1.getTime() === date2.getTime();
          },

          getToday(timezone, callback) {
            return callback(new Date().toISOString().split('T')[0]);
          },

          UTCToWallTime(date, timezone, callback) {
            callback(date);
          },

          WallTimeToUTC(date, timezone, callback) {
            callback(date);
          },

          translateToOtherCalendar(date) {
            return date;
          },

          formatDateTimeUTC(date) {
            return date;
          },

          translateFromOtherCalendar(date) {
            return date;
          }

        };
      },

      getPathPrefix() {
  return '/slds/2.8.3/';
      },

      getToken(name) {
  return void 0;
      }

    };
  }

  function getDefaultConfig() {
    return window.$A !== undefined && window.$A.localizationService ? getConfigFromAura(window.$A) : createStandAloneConfig();
  }

  let PROVIDED_IMPL = getDefaultConfig();
  function getPathPrefix() {
    return PROVIDED_IMPL && PROVIDED_IMPL.getPathPrefix && PROVIDED_IMPL.getPathPrefix() || '';
  }
  function getToken(name) {
    return PROVIDED_IMPL && PROVIDED_IMPL.getToken && PROVIDED_IMPL.getToken(name);
  }

  var _tmpl = void 0;

  // Taken from https://github.com/jonathantneal/svg4everybody/pull/139
  // Remove this iframe-in-edge check once the following is resolved https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/8323875/
  const isEdgeUA = /\bEdge\/.(\d+)\b/.test(navigator.userAgent);
  const inIframe = window.top !== window.self;
  const isIframeInEdge = isEdgeUA && inIframe;
  var isIframeInEdge$1 = Engine.registerComponent(isIframeInEdge, {
    tmpl: _tmpl
  });

  // Taken from https://git.soma.salesforce.com/aura/lightning-global/blob/999dc35f948246181510df6e56f45ad4955032c2/src/main/components/lightning/SVGLibrary/stamper.js#L38-L60
  function fetchSvg(url) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', url);
      xhr.send();

      xhr.onreadystatechange = () => {
        if (xhr.readyState === 4) {
          if (xhr.status === 200) {
            resolve(xhr.responseText);
          } else {
            reject(xhr);
          }
        }
      };
    });
  }

  // Which looks like it was inspired by https://github.com/jonathantneal/svg4everybody/blob/377d27208fcad3671ed466e9511556cb9c8b5bd8/lib/svg4everybody.js#L92-L107
  // Modify at your own risk!

  const newerIEUA = /\bTrident\/[567]\b|\bMSIE (?:9|10)\.0\b/;
  const webkitUA = /\bAppleWebKit\/(\d+)\b/;
  const olderEdgeUA = /\bEdge\/12\.(\d+)\b/;
  const isIE = newerIEUA.test(navigator.userAgent) || (navigator.userAgent.match(olderEdgeUA) || [])[1] < 10547 || (navigator.userAgent.match(webkitUA) || [])[1] < 537;
  const supportsSvg = !isIE && !isIframeInEdge$1;
  var supportsSvg$1 = Engine.registerComponent(supportsSvg, {
    tmpl: _tmpl
  });

  /**
  This polyfill injects SVG sprites into the document for clients that don't
  fully support SVG. We do this globally at the document level for performance
  reasons. This causes us to lose namespacing of IDs across sprites. For example,
  if both #image from utility sprite and #image from doctype sprite need to be
  rendered on the page, both end up as #image from the doctype sprite (last one
  wins). SLDS cannot change their image IDs due to backwards-compatibility
  reasons so we take care of this issue at runtime by adding namespacing as we
  polyfill SVG elements.

  For example, given "/assets/icons/action-sprite/svg/symbols.svg#approval", we
  replace the "#approval" id with "#${namespace}-approval" and a similar
  operation is done on the corresponding symbol element.
  **/
  const svgTagName = /svg/i;

  const isSvgElement = el => el && svgTagName.test(el.nodeName);

  const requestCache = {};
  const symbolEls = {};
  const svgFragments = {};
  const spritesContainerId = 'slds-svg-sprites';
  let spritesEl;
  function polyfill(el) {
    if (!supportsSvg$1 && isSvgElement(el)) {
      if (!spritesEl) {
        spritesEl = document.createElement('svg');
        spritesEl.xmlns = 'http://www.w3.org/2000/svg';
        spritesEl['xmlns:xlink'] = 'http://www.w3.org/1999/xlink';
        spritesEl.style.display = 'none';
        spritesEl.id = spritesContainerId;
        document.body.insertBefore(spritesEl, document.body.childNodes[0]);
      }

      Array.from(el.getElementsByTagName('use')).forEach(use => {
        // We access the href differently in raptor and in aura, probably
        // due to difference in the way the svg is constructed.
        const src = use.getAttribute('xlink:href') || use.getAttribute('href');

        if (src) {
          // "/assets/icons/action-sprite/svg/symbols.svg#approval" =>
          // ["/assets/icons/action-sprite/svg/symbols.svg", "approval"]
          const parts = src.split('#');
          const url = parts[0];
          const id = parts[1];
          const namespace = url.replace(/[^\w]/g, '-');
          const href = `#${namespace}-${id}`;

          if (url.length) {
            // set the HREF value to no longer be an external reference
            if (use.getAttribute('xlink:href')) {
              use.setAttribute('xlink:href', href);
            } else {
              use.setAttribute('href', href);
            } // only insert SVG content if it hasn't already been retrieved


            if (!requestCache[url]) {
              requestCache[url] = fetchSvg(url);
            }

            requestCache[url].then(svgContent => {
              // create a document fragment from the svgContent returned (is parsed by HTML parser)
              if (!svgFragments[url]) {
                const svgFragment = document.createRange().createContextualFragment(svgContent);
                svgFragments[url] = svgFragment;
              }

              if (!symbolEls[href]) {
                const svgFragment = svgFragments[url];
                const symbolEl = svgFragment.querySelector(`#${id}`);
                symbolEls[href] = true;
                symbolEl.id = `${namespace}-${id}`;
                spritesEl.appendChild(symbolEl);
              }
            });
          }
        }
      });
    }
  }

  const validNameRe = /^([a-zA-Z]+):([a-zA-Z]\w*)$/;
  const underscoreRe = /_/g;
  let pathPrefix;
  const tokenNameMap = Object.assign(Object.create(null), {
    action: 'lightning.actionSprite',
    custom: 'lightning.customSprite',
    doctype: 'lightning.doctypeSprite',
    standard: 'lightning.standardSprite',
    utility: 'lightning.utilitySprite'
  });
  const defaultTokenValueMap = Object.assign(Object.create(null), {
    'lightning.actionSprite': '/assets/icons/action-sprite/svg/symbols.svg',
    'lightning.customSprite': '/assets/icons/custom-sprite/svg/symbols.svg',
    'lightning.doctypeSprite': '/assets/icons/doctype-sprite/svg/symbols.svg',
    'lightning.standardSprite': '/assets/icons/standard-sprite/svg/symbols.svg',
    'lightning.utilitySprite': '/assets/icons/utility-sprite/svg/symbols.svg'
  });

  const getDefaultBaseIconPath = category => defaultTokenValueMap[tokenNameMap[category]];

  const getBaseIconPath = category => getToken(tokenNameMap[category]) || getDefaultBaseIconPath(category);

  const getMatchAtIndex = index => iconName => {
    const result = validNameRe.exec(iconName);
    return result ? result[index] : '';
  };

  const getCategory = getMatchAtIndex(1);
  const getName = getMatchAtIndex(2);
  const isValidName = iconName => validNameRe.test(iconName);
  const getIconPath = iconName => {
    pathPrefix = pathPrefix !== undefined ? pathPrefix : getPathPrefix();

    if (isValidName(iconName)) {
      const baseIconPath = getBaseIconPath(getCategory(iconName));

      if (baseIconPath) {
        // This check was introduced the following MS-Edge issue:
        // https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/9655192/
        // If and when this get fixed, we can safely remove this block of code.
        if (isIframeInEdge$1) {
          // protocol => 'https:' or 'http:'
          // host => hostname + port
          const origin = `${window.location.protocol}//${window.location.host}`;
          return `${origin}${pathPrefix}${baseIconPath}#${getName(iconName)}`;
        }

        return `${pathPrefix}${baseIconPath}#${getName(iconName)}`;
      }
    }

    return '';
  };
  const computeSldsClass = iconName => {
    if (isValidName(iconName)) {
      const category = getCategory(iconName);
      const name = getName(iconName).replace(underscoreRe, '-');
      return `slds-icon-${category}-${name}`;
    }

    return '';
  };

  const isSafari = window.safari && window.safari.pushNotification && window.safari.pushNotification.toString() === '[object SafariRemoteNotification]'; // [W-3421985] https://bugs.webkit.org/show_bug.cgi?id=162866
  // https://git.soma.salesforce.com/aura/lightning-global/blob/82e8bfd02846fa7e6b3e7549a64be95b619c4b1f/src/main/components/lightning/primitiveIcon/primitiveIconHelper.js#L53-L56

  function safariA11yPatch(svgElement) {
    if (!svgElement || !isSafari) {
      return;
    } // In case we're dealing with a proxied element.


    svgElement = Engine.unwrap(svgElement);
    const use = svgElement.querySelector('use');

    if (!use) {
      return;
    }

    svgElement.insertBefore(document.createTextNode('\n'), use); // If use.nextSibling is null, the text node is added to the end of
    // the list of children of the SVG element.
    // https://developer.mozilla.org/en-US/docs/Web/API/Node/insertBefore

    svgElement.insertBefore(document.createTextNode('\n'), use.nextSibling);
  }

  function stylesheet(hostSelector, shadowSelector, nativeShadow) {
    return "_:-ms-lang(x)" + shadowSelector + ", svg" + shadowSelector + " {pointer-events: none;}\n";
  }
  var _implicitStylesheets = [stylesheet];

  function tmpl($api, $cmp, $slotset, $ctx) {
    const {
      h: api_element
    } = $api;
    return [api_element("svg", {
      className: $cmp.computedClass,
      attrs: {
        "focusable": "false",
        "data-key": $cmp.name,
        "aria-hidden": "true"
      },
      key: 2
    }, [api_element("use", {
      attrs: {
        "xlink:href": Engine.sanitizeAttribute("use", "http://www.w3.org/2000/svg", "xlink:href", $cmp.href)
      },
      key: 3
    }, [])])];
  }

  var _tmpl$1 = Engine.registerTemplate(tmpl);
  tmpl.stylesheets = [];

  if (_implicitStylesheets) {
    tmpl.stylesheets.push.apply(tmpl.stylesheets, _implicitStylesheets);
  }
  tmpl.stylesheetTokens = {
    hostAttribute: "lightning-primitiveIcon_primitiveIcon-host",
    shadowAttribute: "lightning-primitiveIcon_primitiveIcon"
  };

  class LightningPrimitiveIcon extends Engine.LightningElement {
    constructor(...args) {
      super(...args);
      this.iconName = void 0;
      this.src = void 0;
      this.svgClass = void 0;
      this.size = 'medium';
      this.variant = void 0;
    }

    renderedCallback() {
      if (this.iconName !== this.prevIconName) {
        this.prevIconName = this.iconName;
        const svgElement = this.template.querySelector('svg');
        polyfill(svgElement);
        safariA11yPatch(svgElement);
      }
    }

    get href() {
      return this.src || getIconPath(this.iconName);
    }

    get name() {
      return getName(this.iconName);
    }

    get normalizedSize() {
      return normalizeString(this.size, {
        fallbackValue: 'medium',
        validValues: ['xx-small', 'x-small', 'small', 'medium', 'large']
      });
    }

    get normalizedVariant() {
      // NOTE: Leaving a note here because I just wasted a bunch of time
      // investigating why both 'bare' and 'inverse' are supported in
      // lightning-primitive-icon. lightning-icon also has a deprecated
      // 'bare', but that one is synonymous to 'inverse'. This 'bare' means
      // that no classes should be applied. So this component needs to
      // support both 'bare' and 'inverse' while lightning-icon only needs to
      // support 'inverse'.
      return normalizeString(this.variant, {
        fallbackValue: '',
        validValues: ['bare', 'error', 'inverse', 'warning']
      });
    }

    get computedClass() {
      const {
        normalizedSize,
        normalizedVariant
      } = this;
      const classes = classSet(this.svgClass);

      if (normalizedVariant !== 'bare') {
        classes.add('slds-icon');
      }

      switch (normalizedVariant) {
        case 'error':
          classes.add('slds-icon-text-error');
          break;

        case 'warning':
          classes.add('slds-icon-text-warning');
          break;

        case 'inverse':
        case 'bare':
          break;

        default:
          // if custom icon is set, we don't want to set
          // the text-default class
          if (!this.src) {
            classes.add('slds-icon-text-default');
          }

      }

      if (normalizedSize !== 'medium') {
        classes.add(`slds-icon_${normalizedSize}`);
      }

      return classes.toString();
    }

  }

  Engine.registerDecorators(LightningPrimitiveIcon, {
    publicProps: {
      iconName: {
        config: 0
      },
      src: {
        config: 0
      },
      svgClass: {
        config: 0
      },
      size: {
        config: 0
      },
      variant: {
        config: 0
      }
    }
  });

  var primitiveIcon = Engine.registerComponent(LightningPrimitiveIcon, {
    tmpl: _tmpl$1
  });

  function tmpl$1($api, $cmp, $slotset, $ctx) {
    const {
      c: api_custom_element,
      d: api_dynamic,
      h: api_element
    } = $api;
    return [api_custom_element("lightning-primitive-icon", primitiveIcon, {
      props: {
        "iconName": $cmp.state.iconName,
        "size": $cmp.size,
        "variant": $cmp.variant,
        "src": $cmp.state.src
      },
      key: 2
    }, []), $cmp.alternativeText ? api_element("span", {
      classMap: {
        "slds-assistive-text": true
      },
      key: 3
    }, [api_dynamic($cmp.alternativeText)]) : null];
  }

  var _tmpl$2 = Engine.registerTemplate(tmpl$1);
  tmpl$1.stylesheets = [];
  tmpl$1.stylesheetTokens = {
    hostAttribute: "lightning-icon_icon-host",
    shadowAttribute: "lightning-icon_icon"
  };

  /**
   * Represents a visual element that provides context and enhances usability.
   */

  class LightningIcon extends Engine.LightningElement {
    constructor(...args) {
      super(...args);
      this.state = {};
      this.alternativeText = void 0;
    }

    /**
     * A uri path to a custom svg sprite, including the name of the resouce,
     * for example: /assets/icons/standard-sprite/svg/test.svg#icon-heart
     * @type {string}
     */
    get src() {
      return this.privateSrc;
    }

    set src(value) {
      this.privateSrc = value; // if value is not present, then we set the state back
      // to the original iconName that was passed
      // this might happen if the user sets a custom icon, then
      // decides to revert back to SLDS by removing the src attribute

      if (!value) {
        this.state.iconName = this.iconName;
        this.classList.remove('slds-icon-standard-default');
      } // if isIE11 and the src is set
      // we'd like to show the 'standard:default' icon instead
      // for performance reasons.


      if (value && isIE11) {
        this.setDefault();
        return;
      }

      this.state.src = value;
    }
    /**
     * The Lightning Design System name of the icon.
     * Names are written in the format 'utility:down' where 'utility' is the category,
     * and 'down' is the specific icon to be displayed.
     * @type {string}
     * @required
     */


    get iconName() {
      return this.privateIconName;
    }

    set iconName(value) {
      this.privateIconName = value; // if src is set, we don't need to validate
      // iconName

      if (this.src) {
        return;
      }

      if (isValidName(value)) {
        const isAction = getCategory(value) === 'action'; // update classlist only if new iconName is different than state.iconName
        // otherwise classListMutation receives class:true and class: false and removes slds class

        if (value !== this.state.iconName) {
          classListMutation(this.classList, {
            'slds-icon_container_circle': isAction,
            [computeSldsClass(value)]: true,
            [computeSldsClass(this.state.iconName)]: false
          });
        }

        this.state.iconName = value;
      } else {
        console.warn(`<lightning-icon> Invalid icon name ${value}`); // eslint-disable-line no-console
        // Invalid icon names should render a blank icon. Remove any
        // classes that might have been previously added.

        classListMutation(this.classList, {
          'slds-icon_container_circle': false,
          [computeSldsClass(this.state.iconName)]: false
        });
        this.state.iconName = undefined;
      }
    }
    /**
     * The size of the icon. Options include xx-small, x-small, small, medium, or large.
     * The default is medium.
     * @type {string}
     * @default medium
     */


    get size() {
      return normalizeString(this.state.size, {
        fallbackValue: 'medium',
        validValues: ['xx-small', 'x-small', 'small', 'medium', 'large']
      });
    }

    set size(value) {
      this.state.size = value;
    }
    /**
     * The variant changes the appearance of a utility icon.
     * Accepted variants include inverse, warning, and error.
     * Use the inverse variant to implement a white fill in utility icons on dark backgrounds.
     * @type {string}
     */


    get variant() {
      return normalizeVariant(this.state.variant, this.state.iconName);
    }

    set variant(value) {
      this.state.variant = value;
    }

    connectedCallback() {
      this.classList.add('slds-icon_container');
    }

    setDefault() {
      this.state.src = undefined;
      this.state.iconName = 'standard:default';
      this.classList.add('slds-icon-standard-default');
    }

  }

  Engine.registerDecorators(LightningIcon, {
    publicProps: {
      alternativeText: {
        config: 0
      },
      src: {
        config: 3
      },
      iconName: {
        config: 3
      },
      size: {
        config: 3
      },
      variant: {
        config: 3
      }
    },
    track: {
      state: 1
    }
  });

  var icon = Engine.registerComponent(LightningIcon, {
    tmpl: _tmpl$2
  });

  function normalizeVariant(variant, iconName) {
    // Unfortunately, the `bare` variant was implemented to do what the
    // `inverse` variant should have done. Keep this logic for as long as
    // we support the `bare` variant.
    if (variant === 'bare') {
      // TODO: Deprecation warning using strippable assertion
      variant = 'inverse';
    }

    if (getCategory(iconName) === 'utility') {
      return normalizeString(variant, {
        fallbackValue: '',
        validValues: ['error', 'inverse', 'warning']
      });
    }

    return 'inverse';
  }

  function tmpl$2($api, $cmp, $slotset, $ctx) {
    const {
      c: api_custom_element,
      h: api_element,
      d: api_dynamic,
      s: api_slot
    } = $api;
    return [api_element("article", {
      className: $cmp.computedWrapperClassNames,
      key: 2
    }, [api_element("header", {
      classMap: {
        "slds-card__header": true,
        "slds-grid": true
      },
      key: 3
    }, [api_element("div", {
      classMap: {
        "slds-media": true,
        "slds-media_center": true,
        "slds-has-flexi-truncate": true
      },
      key: 4
    }, [$cmp.hasIcon ? api_element("div", {
      classMap: {
        "slds-media__figure": true
      },
      key: 6
    }, [api_custom_element("lightning-icon", icon, {
      props: {
        "iconName": $cmp.iconName,
        "size": "small"
      },
      key: 7
    }, [])]) : null, api_element("div", {
      classMap: {
        "slds-media__body": true,
        "slds-truncate": true
      },
      key: 8
    }, [api_element("h2", {
      key: 9
    }, [api_element("span", {
      classMap: {
        "slds-text-heading_small": true
      },
      key: 10
    }, [$cmp.hasStringTitle ? api_dynamic($cmp.title) : null, !$cmp.hasStringTitle ? api_slot("title", {
      attrs: {
        "name": "title"
      },
      key: 13
    }, [], $slotset) : null])])])]), api_element("div", {
      classMap: {
        "slds-no-flex": true
      },
      key: 14
    }, [api_slot("actions", {
      attrs: {
        "name": "actions"
      },
      key: 15
    }, [], $slotset)])]), api_element("div", {
      classMap: {
        "slds-card__body": true
      },
      key: 16
    }, [api_slot("", {
      key: 17
    }, [], $slotset)]), api_element("div", {
      classMap: {
        "slds-card__footer": true
      },
      key: 18
    }, [api_slot("footer", {
      attrs: {
        "name": "footer"
      },
      key: 19
    }, [api_element("span", {
      attrs: {
        "data-id": "default-content"
      },
      key: 20
    }, [])], $slotset)])])];
  }

  var _tmpl$3 = Engine.registerTemplate(tmpl$2);
  tmpl$2.slots = ["title", "actions", "", "footer"];
  tmpl$2.stylesheets = [];
  tmpl$2.stylesheetTokens = {
    hostAttribute: "lightning-card_card-host",
    shadowAttribute: "lightning-card_card"
  };

  function isNarrow(variant) {
    return typeof variant === 'string' && variant.toLowerCase() === 'narrow';
  }
  function isBase(variant) {
    return typeof variant === 'string' && variant.toLowerCase() === 'base';
  }

  /**
   * @slot title The card title, which can be represented by a `header` or `h1` element.
   * The title is displayed at the top of the card, to the right of the icon.
   * Alternatively, use the `title` attribute if you don't need to pass in extra markup in your title.
   * @slot actions Actionable components, such as `lightning-button` or `lightning-button-menu`.
   * Actions are displayed on the top right corner of the card next to the title.
   * @slot footer The card footer, which is displayed at the bottom of the card and is usually optional.
   * For example, the footer can display a "View All" link to navigate to a list view.
   */

  /**
   * Cards apply a container around a related grouping of information.
   */

  class LightningCard extends Engine.LightningElement {
    constructor(...args) {
      super(...args);
      this.title = void 0;
      this.iconName = void 0;
      this.privateVariant = 'base';
    }

    set variant(value) {
      if (isNarrow(value) || isBase(value)) {
        this.privateVariant = value;
      } else {
        this.privateVariant = 'base';
      }
    }
    /**
     * The variant changes the appearance of the card.
     * Accepted variants include base or narrow.
     * This value defaults to base.
     *
     * @type {string}
     * @default base
     */


    get variant() {
      return this.privateVariant;
    }

    renderedCallback() {
      const footerWrapper = this.template.querySelector('.slds-card__footer');
      const noFooterContent = this.template.querySelector('slot[name="footer"] [data-id="default-content"]');

      if (noFooterContent) {
        if (footerWrapper.remove) {
          footerWrapper.remove();
        } else if (footerWrapper.parentNode) {
          // IE11 doesn't support remove. https://caniuse.com/#feat=childnode-remove
          // TODO: remove when lwc can polyfill node.remove.
          footerWrapper.parentNode.removeChild(footerWrapper);
        }
      }
    }

    get computedWrapperClassNames() {
      return classSet('slds-card').add({
        'slds-card_narrow': isNarrow(this.privateVariant)
      });
    }

    get hasIcon() {
      return !!this.iconName;
    }

    get hasStringTitle() {
      return !!this.title;
    }

  }

  Engine.registerDecorators(LightningCard, {
    publicProps: {
      title: {
        config: 0
      },
      iconName: {
        config: 0
      },
      variant: {
        config: 3
      }
    },
    track: {
      privateVariant: 1
    }
  });

  var card = Engine.registerComponent(LightningCard, {
    tmpl: _tmpl$3
  });

  var labelAutoPlay = 'Stop auto-play';

  var labelTabString = 'Tab';

  function tmpl$3($api, $cmp, $slotset, $ctx) {
    const {
      c: api_custom_element,
      d: api_dynamic,
      h: api_element,
      b: api_bind,
      s: api_slot,
      gid: api_scoped_id,
      ti: api_tab_index,
      k: api_key,
      i: api_iterator
    } = $api;
    const {
      _m0,
      _m1,
      _m2,
      _m3
    } = $ctx;
    return [api_element("div", {
      classMap: {
        "slds-carousel": true
      },
      key: 2
    }, [api_element("div", {
      classMap: {
        "slds-carousel__stage": true
      },
      key: 3
    }, [!$cmp.disableAutoScroll ? api_element("span", {
      classMap: {
        "slds-carousel__autoplay": true
      },
      key: 5
    }, [api_element("button", {
      classMap: {
        "slds-button": true,
        "slds-button_icon": true,
        "slds-button_icon-border-filled": true,
        "slds-button_icon-x-small": true
      },
      attrs: {
        "aria-pressed": $cmp.ariaPressed,
        "title": $cmp.togglePlayString
      },
      key: 6,
      on: {
        "click": _m0 || ($ctx._m0 = api_bind($cmp.toggleAutoScroll))
      }
    }, [api_custom_element("lightning-primitive-icon", primitiveIcon, {
      classMap: {
        "slds-button__icon": true
      },
      props: {
        "iconName": $cmp.autoScrollIcon,
        "size": "x-small"
      },
      key: 7
    }, []), api_element("span", {
      classMap: {
        "slds-assistive-text": true
      },
      key: 8
    }, [api_dynamic($cmp.i18n.autoPlay)])])]) : null, api_element("div", {
      classMap: {
        "slds-carousel__panels": true
      },
      style: $cmp.carouselPanelsStyle,
      key: 9,
      on: {
        "privateimageregister": _m1 || ($ctx._m1 = api_bind($cmp.imageRegisterHandler))
      }
    }, [api_slot("", {
      key: 10
    }, [], $slotset)]), api_element("ul", {
      classMap: {
        "slds-carousel__indicators": true
      },
      attrs: {
        "role": "tablist"
      },
      key: 11,
      on: {
        "keydown": _m3 || ($ctx._m3 = api_bind($cmp.keyDownHandler))
      }
    }, api_iterator($cmp.paginationItems, function (paginationItem, paginationIndex) {
      return api_element("li", {
        classMap: {
          "slds-carousel__indicator": true
        },
        attrs: {
          "role": "presentation",
          "data-index": paginationIndex
        },
        key: api_key(13, paginationItem.key),
        on: {
          "click": _m2 || ($ctx._m2 = api_bind($cmp.onItemSelect))
        }
      }, [api_element("a", {
        className: paginationItem.className,
        attrs: {
          "id": api_scoped_id(paginationItem.id),
          "href": "javascript:void(0);",
          "role": "tab",
          "tabindex": api_tab_index(paginationItem.tabIndex),
          "aria-selected": paginationItem.ariaSelected,
          "aria-controls": api_scoped_id(paginationItem.contentId),
          "title": paginationItem.tabTitle
        },
        key: 14
      }, [api_element("span", {
        classMap: {
          "slds-assistive-text": true
        },
        key: 15
      }, [api_dynamic(paginationItem.tabTitle)])])]);
    }))])])];
  }

  var _tmpl$4 = Engine.registerTemplate(tmpl$3);
  tmpl$3.slots = [""];
  tmpl$3.stylesheets = [];
  tmpl$3.stylesheetTokens = {
    hostAttribute: "lightning-carousel_carousel-host",
    shadowAttribute: "lightning-carousel_carousel"
  };

  const INDICATOR_ACTION = 'slds-carousel__indicator-action';
  const SLDS_ACTIVE = 'slds-is-active';
  const PAUSE_ICON = 'utility:pause';
  const PLAY_ICON = 'utility:right';
  const FALSE_STRING = 'false';
  const TRUE_STRING = 'true';
  const i18n = {
    autoPlay: labelAutoPlay,
    tabString: labelTabString
  };
  /**
   * A collection of images that are displayed one at a time.
   */

  class LightningCarousel extends Engine.LightningElement {
    constructor(...args) {
      super(...args);
      this.scrollDuration = 5;
      this.paginationItems = [];
      this.autoScrollIcon = PAUSE_ICON;
      this.ariaPressed = FALSE_STRING;
      this.carouselPanelsStyle = void 0;
      this.togglePlayString = i18n.autoPlay;
      this.initialRender = true;
      this.activeIndexItem = 0;
      this.carouselItems = [];
      this.autoScrollTimeOut = void 0;
    }

    get i18n() {
      return i18n;
    }
    /**
     * If present, images do not automatically scroll and users must click the indicators to scroll.
     * @type {boolean}
     * @default false
     */


    get disableAutoScroll() {
      return this._disableAutoScroll || false;
    }

    set disableAutoScroll(value) {
      this._disableAutoScroll = normalizeBoolean(value);
    }
    /**
     * If present, the carousel stops looping
     * after the last item is displayed.
     *
     * @type {boolean}
     * @default false
     */


    get disableAutoRefresh() {
      return this._disableAutoRefresh || false;
    }

    set disableAutoRefresh(value) {
      this._disableAutoRefresh = normalizeBoolean(value);
    }
    /**
     * The auto scroll duration. The default is 5 seconds, after that the next
     * image is displayed.
     *
     * @type {number}
     * @default 5
     */


    /**
     * Handles the registration for all the items inside the carousel that have been
     * loaded via <slot></slot>. It also loads the data for the pagination state object
     * and sets the active item we want to display on first render.
     * @param {Object} event - The event object
     */
    imageRegisterHandler(event) {
      const target = event.target,
            item = event.detail,
            currentIndex = this.carouselItems.length,
            isItemActive = currentIndex === this.activeIndexItem,
            paginationItemDetail = {
        key: item.guid,
        id: `pagination-item-${currentIndex}`,
        tabTitle: target.description ? target.description + ' ' + i18n.tabString : null,
        className: isItemActive ? INDICATOR_ACTION + ' ' + SLDS_ACTIVE : INDICATOR_ACTION,
        tabIndex: isItemActive ? '0' : '-1',
        contentId: event.detail.contentId,
        ariaSelected: isItemActive ? TRUE_STRING : FALSE_STRING
      };

      if (currentIndex > 5) {
        // console.error('Only up to 5 carousel Images are allowed at a time');
        return;
      } // if the activeIndexItem is equal to the currentIndex on the registration process
      // then we se set it active. paginationItemDetail also needs to reflect the active state.


      if (isItemActive) {
        item.callbacks.select();
      }

      item.callbacks.setLabelledBy(paginationItemDetail.id);
      this.paginationItems.push(paginationItemDetail);
      this.carouselItems.push(item);
    }
    /**
     * Render callback handler to call up the autoScoller if
     * the property is enabled.
     */


    renderedCallback() {
      if (this.initialRender) {
        if (!this.disableAutoScroll) {
          this.setAutoScroll();
        }
      }

      this.initialRender = false;
    }
    /**
     * Sets up the timeout for the auto scrolling task
     */


    setAutoScroll() {
      // milliseconds
      const scrollDuration = parseInt(this.scrollDuration, 10) * 1000;
      const carouselItemsLength = this.carouselItems.length;

      if (this.activeIndexItem === carouselItemsLength - 1 && this.disableAutoRefresh) {
        this.autoScrollOff();
        return;
      }

      this.cancelAutoScrollTimeOut(); // eslint-disable-next-line lwc/no-set-timeout

      this.autoScrollTimeOut = setTimeout(this.startAutoScroll.bind(this), scrollDuration);
    }
    /**
     * Function that starts the autoScrolling functionallity
     */


    startAutoScroll() {
      this.selectNextSibling();
      this.setAutoScroll();
    }
    /**
     * Cancels the auto scroll timeout task.
     */


    cancelAutoScrollTimeOut() {
      clearTimeout(this.autoScrollTimeOut);
    }
    /**
     * Event handle for toggling on play/pause the autoScroll
     */


    toggleAutoScroll() {
      const ariaPressed = this.ariaPressed;

      if (ariaPressed === FALSE_STRING) {
        this.autoScrollOff();
      } else {
        this.autoScrollOn();
      }
    }
    /**
     * Sets the state for Auto Scroll on.
     */


    autoScrollOn() {
      const carouselItemsLength = this.carouselItems.length;

      if (!this.disableAutoScroll) {
        if (this.activeIndexItem === carouselItemsLength - 1 && this.disableAutoRefresh) {
          this.unselectCurrentItem();
          this.selectNewItem(0);
        }

        this.autoScrollIcon = PAUSE_ICON;
        this.ariaPressed = FALSE_STRING;
        this.setAutoScroll();
      }
    }
    /**
     * Sets the state for Auto Scroll off.
     */


    autoScrollOff() {
      if (!this.disableAutoScroll) {
        this.ariaPressed = TRUE_STRING;
        this.autoScrollIcon = PLAY_ICON;
        this.cancelAutoScrollTimeOut();
      }
    }
    /**
     * Handler for when the user selects a new carousel item via the
     * carousel's pagination. It unselects the current active item and sets
     * active the new item recieved.
     * @param {Object} event - The event object
     */


    onItemSelect(event) {
      const currentTarget = event.currentTarget,
            itemIndex = currentTarget.getAttribute('data-index');
      this.autoScrollOff();

      if (this.activeIndexItem !== itemIndex) {
        this.unselectCurrentItem();
        this.selectNewItem(itemIndex);
        this.activeIndexItem = parseInt(itemIndex, 10);
      }
    }
    /**
     * Unselects the current active item on the carousel.
     */


    unselectCurrentItem() {
      const activePaginationItem = this.paginationItems[this.activeIndexItem];
      activePaginationItem.tabIndex = '-1';
      activePaginationItem.ariaSelected = FALSE_STRING;
      activePaginationItem.className = INDICATOR_ACTION;
      this.carouselItems[this.activeIndexItem].callbacks.unselect();
    }
    /**
     * Selects a new item on the carousel based on the index provided.
     * @param {Number} itemIndex - The index of the item to be selected
     */


    selectNewItem(itemIndex) {
      const activePaginationItem = this.paginationItems[itemIndex];

      if (!this.carouselItems[itemIndex].callbacks.isSelected()) {
        activePaginationItem.tabIndex = '0';
        activePaginationItem.ariaSelected = TRUE_STRING;
        activePaginationItem.className = INDICATOR_ACTION + ' ' + SLDS_ACTIVE;
        this.carouselPanelsStyle = `transform:translateX(-${itemIndex * 100}%);`;
        this.carouselItems[itemIndex].callbacks.select();
        this.activeIndexItem = itemIndex;
      }
    }
    /**
     * Key press event handler.
     * Listens to key presses and reacts moving the carousel items to next or previous
     * when the focus is active.
     * @param {Object} event - The event object
     */


    keyDownHandler(event) {
      const key = event.keyCode;
      let indicatorActionsElements = this.indicatorActionsElements;

      if (key === keyCodes.right) {
        event.preventDefault();
        event.stopPropagation();
        this.autoScrollOff();
        this.selectNextSibling();
      }

      if (key === keyCodes.left) {
        event.preventDefault();
        event.stopPropagation();
        this.autoScrollOff();
        this.selectPreviousSibling();
      } // we cache them the first time


      if (!indicatorActionsElements) {
        indicatorActionsElements = this.template.querySelectorAll('.slds-carousel__indicator-action');
        this.indicatorActionsElements = indicatorActionsElements;
      } // we want to make sure that while we are using the keyboard
      // navigation we are focusing on the right indicator


      indicatorActionsElements[this.activeIndexItem].focus();
    }
    /**
     * Marks as active the next sibiling to the
     * current active index.
     */


    selectNextSibling() {
      const carouselItemsLength = this.carouselItems.length;
      let itemIndex = this.activeIndexItem + 1; // go to first item

      if (this.activeIndexItem === carouselItemsLength - 1) {
        if (this.disableAutoRefresh) {
          this.autoScrollOff();
          return;
        }

        itemIndex = 0;
      }

      this.unselectCurrentItem();
      this.selectNewItem(itemIndex);
    }
    /**
     * Marks as active the previous sibiling to the
     * current active index.
     */


    selectPreviousSibling() {
      const carouselItemsLength = this.carouselItems.length;
      let itemIndex = this.activeIndexItem - 1; // go to last item

      if (this.activeIndexItem === 0) {
        if (this.disableAutoRefresh) {
          this.autoScrollOff();
          return;
        }

        itemIndex = carouselItemsLength - 1;
      }

      this.unselectCurrentItem();
      this.selectNewItem(itemIndex);
    }

  }

  Engine.registerDecorators(LightningCarousel, {
    publicProps: {
      disableAutoScroll: {
        config: 3
      },
      disableAutoRefresh: {
        config: 3
      },
      scrollDuration: {
        config: 0
      }
    },
    track: {
      paginationItems: 1,
      autoScrollIcon: 1,
      ariaPressed: 1,
      carouselPanelsStyle: 1
    }
  });

  var carousel = Engine.registerComponent(LightningCarousel, {
    tmpl: _tmpl$4
  });

  function tmpl$4($api, $cmp, $slotset, $ctx) {
    const {
      h: api_element,
      d: api_dynamic,
      ti: api_tab_index,
      gid: api_scoped_id
    } = $api;
    return [api_element("div", {
      attrs: {
        "role": "tabpanel",
        "id": api_scoped_id("carousel-image"),
        "aria-hidden": $cmp.ariaHidden
      },
      key: 2
    }, [api_element("a", {
      classMap: {
        "slds-carousel__panel-action": true,
        "slds-text-link_reset": true
      },
      attrs: {
        "href": $cmp.href,
        "tabindex": api_tab_index($cmp.tabIndex)
      },
      key: 3
    }, [api_element("div", {
      classMap: {
        "slds-carousel__image": true
      },
      key: 4
    }, [api_element("img", {
      attrs: {
        "src": $cmp.src,
        "alt": $cmp.alternativeText
      },
      key: 5
    }, [])]), api_element("div", {
      classMap: {
        "slds-carousel__content": true
      },
      key: 6
    }, [api_element("h2", {
      classMap: {
        "slds-carousel__content-title": true
      },
      key: 7
    }, [api_dynamic($cmp.header)]), api_element("p", {
      key: 8
    }, [api_dynamic($cmp.description)])])])])];
  }

  var _tmpl$5 = Engine.registerTemplate(tmpl$4);
  tmpl$4.stylesheets = [];
  tmpl$4.stylesheetTokens = {
    hostAttribute: "lightning-carouselImage_carouselImage-host",
    shadowAttribute: "lightning-carouselImage_carouselImage"
  };

  /**
   * Class representing a Ligthing Carousel Image.
   * It displays an image on the page with a description and title
   * @extends Element
   */

  class LightningCarouselImage extends Engine.LightningElement {
    /**
     * {String} src - The image source
     */
    get src() {
      return this._src;
    }

    set src(value) {
      this._src = value;
      this.validateSrc();
    }
    /**
     * {String} header - The header label
     */


    /**
     * {String} alternativeText - The alt attribute of the image
     */
    get alternativeText() {
      return this._alternativeText;
    }

    set alternativeText(value) {
      this._alternativeText = value;
      this.validateAlternativeText();
    }
    /**
     * {String} href - The link for the call to action
     */


    /**
     * Carousel Image constructor. We initialize some default values and set the className attribute
     */
    constructor() {
      super();
      this._src = void 0;
      this.header = void 0;
      this.description = void 0;
      this._alternativeText = void 0;
      this.href = void 0;
      this.ariaHidden = 'true';
      this.ariaLabelledby = void 0;
      this.computedId = void 0;
      this.tabIndex = '-1';
      this._selected = false;
      this.initialRender = true;
      this.selected = false;
    }
    /**
     * setter function for the _selected attribute.
     * It also calls the classListMutation with the new value
     * @param {Boolean} value -  The value of the active item in
     */


    set selected(value) {
      this._selected = value;

      if (value === true) {
        this.ariaHidden = 'false';
        this.setTabIndex('0');
      } else {
        this.ariaHidden = 'true';
        this.setTabIndex('-1');
      }
    }

    get selected() {
      return this._selected;
    }

    setLabelledBy(value) {
      this.panelElement.setAttribute('aria-labelledby', value);
    }
    /**
     * setter function for the tabIndex attribute.
     * @param {String} value -  The value of the active item in
     */


    setTabIndex(value) {
      this.tabIndex = value;
    }
    /**
     * {Function} select - Marks and displays the image as selected
     */


    select() {
      const privateimageselect = new CustomEvent('privateimageselect', {
        bubbles: true,
        composed: true
      });
      this.selected = true;
      this.dispatchEvent(privateimageselect);
    }
    /**
     * {Function} unselect - Hides the image. Set's the selected property to false.
     */


    unselect() {
      this.selected = false;
    }
    /**
     * {Function} isSelected - Hides the image. Set's the selected property to false
     * @returns  {Boolean} the selected property.
     */


    isSelected() {
      return this.selected;
    }

    validateAll() {
      this.validateAlternativeText();
      this.validateSrc();
    }

    validateAlternativeText() {
      assert(typeof this._alternativeText === 'string' && this._alternativeText.length, `<lightning-carousel-image> The "alternative-text" attribute value is required.`);
    }

    validateSrc() {
      assert(typeof this._src === 'string' && this._src.length, `<lightning-carousel-image> The "src" attribute value is required.`);
    }
    /**
     * Once we are connected, we fire a register event so the Carousel component can register
     * the carousel images.
     */


    renderedCallback() {
      if (this.initialRender) {
        this.validateAll();
        this.panelElement = this.template.querySelector('div');
        const privateimageregister = new CustomEvent('privateimageregister', {
          bubbles: true,
          composed: true,
          detail: {
            callbacks: {
              select: this.select.bind(this),
              unselect: this.unselect.bind(this),
              isSelected: this.isSelected.bind(this),
              setTabIndex: this.setTabIndex.bind(this),
              setLabelledBy: this.setLabelledBy.bind(this)
            },
            contentId: this.panelElement.getAttribute('id'),
            guid: guid()
          }
        });
        this.classList.add('slds-carousel__panel');
        this.dispatchEvent(privateimageregister);
        this.initialRender = false;
      }
    }

  }

  Engine.registerDecorators(LightningCarouselImage, {
    publicProps: {
      src: {
        config: 3
      },
      header: {
        config: 0
      },
      description: {
        config: 0
      },
      alternativeText: {
        config: 3
      },
      href: {
        config: 0
      }
    },
    track: {
      _src: 1,
      _alternativeText: 1,
      ariaHidden: 1,
      ariaLabelledby: 1,
      computedId: 1,
      tabIndex: 1
    }
  });

  var carouselImage = Engine.registerComponent(LightningCarouselImage, {
    tmpl: _tmpl$5
  });

  function tmpl$5($api, $cmp, $slotset, $ctx) {
    const {
      c: api_custom_element,
      h: api_element
    } = $api;
    return [api_custom_element("lightning-card", card, {
      props: {
        "title": "Image Carousel"
      },
      key: 2
    }, [api_element("p", {
      classMap: {
        "slds-p-horizontal_large": true
      },
      key: 3
    }, [api_custom_element("lightning-carousel", carousel, {
      props: {
        "disableAutoScroll": true
      },
      key: 4
    }, [api_custom_element("lightning-carousel-image", carouselImage, {
      props: {
        "src": "https://camp-innovation-trailheadx.herokuapp.com/images/Codey.png",
        "header": "Codey",
        "description": "Codey moving packages of code.",
        "alternativeText": "Codey moving packages of code around the workspace.",
        "href": "https://developer.salesforce.com/"
      },
      key: 5
    }, []), api_custom_element("lightning-carousel-image", carouselImage, {
      props: {
        "src": "https://camp-innovation-trailheadx.herokuapp.com/images/Astro.png",
        "header": "Astro",
        "description": "Astro coding on a laptop at a desk.",
        "alternativeText": "Astro coding on a laptop at a desk.",
        "href": "https://www.salesforce.com/"
      },
      key: 6
    }, [])])])])];
  }

  var _tmpl$6 = Engine.registerTemplate(tmpl$5);
  tmpl$5.stylesheets = [];
  tmpl$5.stylesheetTokens = {
    hostAttribute: "c-carousel_carousel-host",
    shadowAttribute: "c-carousel_carousel"
  };

  class carousel$1 extends Engine.LightningElement {}

  var carousel$1$1 = Engine.registerComponent(carousel$1, {
    tmpl: _tmpl$6
  });

  function stylesheet$1(hostSelector, shadowSelector, nativeShadow) {
    return "h1" + shadowSelector + " {color: rgb(0, 112, 210);}\np" + shadowSelector + " {font-family: 'Salesforce Sans', Arial, sans-serif;color: rgb(62, 62, 60);}\n";
  }
  var _implicitStylesheets$1 = [stylesheet$1];

  function tmpl$6($api, $cmp, $slotset, $ctx) {
    const {
      d: api_dynamic,
      h: api_element,
      c: api_custom_element
    } = $api;
    return [api_element("div", {
      classMap: {
        "slds-p-around_x-large": true
      },
      key: 2
    }, [api_element("h1", {
      classMap: {
        "slds-text-heading_large": true
      },
      key: 3
    }, [api_dynamic($cmp.state.title)]), api_custom_element("c-carousel", carousel$1$1, {
      key: 4
    }, [])])];
  }

  var _tmpl$7 = Engine.registerTemplate(tmpl$6);
  tmpl$6.stylesheets = [];

  if (_implicitStylesheets$1) {
    tmpl$6.stylesheets.push.apply(tmpl$6.stylesheets, _implicitStylesheets$1);
  }
  tmpl$6.stylesheetTokens = {
    hostAttribute: "c-app_app-host",
    shadowAttribute: "c-app_app"
  };

  class App extends Engine.LightningElement {
    constructor(...args) {
      super(...args);
      this.state = {
        title: 'Welcome to Camp Innovation at TrailheaDX 2019!'
      };
    }

  }

  Engine.registerDecorators(App, {
    track: {
      state: 1
    }
  });

  var app = Engine.registerComponent(App, {
    tmpl: _tmpl$7
  });

  // This is the main entry point to the playground. By default,

  const element = Engine.createElement('c-app', { is: app });
  document.body.appendChild(element);

}(Engine));
