import { LightningElement } from 'lwc';

export default class carousel extends LightningElement {}