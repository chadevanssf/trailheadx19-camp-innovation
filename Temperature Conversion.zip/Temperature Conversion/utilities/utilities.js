function IsHotOrCold(temp, temptype) {
    let hottemp = 100;
    let coldtemp = 32;

    if (temptype == "F") {
        hottemp = 100;
        coldtemp = 32;
    } else if (temptype == "C") {
        hottemp = 37;
        coldtemp = 0;
    }
    if(temp > hottemp) {
        return ' -- Too hot 🔥';
    } 
    if(temp < coldtemp) {
        return ' -- Too cold ⛄';
    }
    return '';
}

function CelsiusToFahrenheit(celsius) {
    let temp = ((celsius * 9/5) + 32).toFixed(2);
    return temp;
}

function FahrenheitToCelsius(fahrenheit){
    let temp = ((fahrenheit - 32) * 5/9).toFixed(1);
    return temp;
}

export { IsHotOrCold, CelsiusToFahrenheit, FahrenheitToCelsius }