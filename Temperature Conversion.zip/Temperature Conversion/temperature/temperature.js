import { LightningElement, track, api } from 'lwc';
// CelsiusToKelvin: add function name here
import { CelsiusToFahrenheit, FahrenheitToCelsius, IsHotOrCold } from 'c/utilities';

export default class Temperature extends LightningElement {
    @track temp = "";
    input = "° Fahrenheit";
    @track inputType = "F";
    output = "° Celsius";
    @track outputType = "C";

    get options() {
        return [
            {
                label: '° Fahrenheit',
                value: 'F',
            },
            {
                label: '° Celsius',
                value: 'C',
            },
            // CelsiusToKelvin: add the new option
        ];
    }
    get Conversion() {
        if (this.inputType == this.outputType) {
            return this.temp;
        }

        if (this.inputType == "C" && this.outputType == "F") {
            return CelsiusToFahrenheit(this.temp);
        }

        if (this.inputType == "F" && this.outputType == "C") {
            return FahrenheitToCelsius(this.temp);
        }
        // CelsiusToKelvin: add the new converstion callout
    }

    get Comfort() {
        return IsHotOrCold(this.temp, this.inputType);
    }

    get hasTemperature() {
        if (this.temp.length > 0) {
            return true;
        }
       
        return false;
    }

    get label(){
        return "Enter " + this.input;
    }

    UpdateTemp(evt){
        this.temp = evt.target.value;
    }

    HandleInputTypeChange(event) {
        this.inputType = event.detail.value;
        var opt = this.options.find(function (element){
           return element.value == event.detail.value;
        });
        this.input = opt.label;
    }

    HandleOutputTypeChange(event) {
        this.outputType = event.detail.value;
        var opt = this.options.find(function (element){
           return element.value == event.detail.value;
        });
        this.output = opt.label;
    }

}