import { LightningElement, api, track } from 'lwc';

export default class todoList extends LightningElement {
    @track filteredTodos = [];

    _todos = [
        {
            title: "first item",
            description: "this helps with the remaining items",
            priority: false,
            completed: true,
        },
        {
            title: "second item",
            description: "deep into the list now",
            priority: true,
            completed: false,
        },
        // AddNewTask: add a new manual task to the list
        {
            title: "third item",
            description: "brand new item on the list",
            priority: true,
            completed: true,
        },
    ];

    priorityFilter = false;

    @api
    get todos() {
        return this._todos;
    }
    set todos(value) {
        this._todos = value;
        this.filterTodos();
    }

    filterTodos() {
        if (this.priorityFilter) {
            this.filteredTodos = this._todos.filter(
                todo => todo.priority === true
            );
        } else {
            this.filteredTodos = this._todos;
        }
    }

    handleCheckboxChange(event) {
        this.priorityFilter = event.target.checked;
        this.filterTodos();
    }
}