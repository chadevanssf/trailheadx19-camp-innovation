import { LightningElement, track } from 'lwc';

export default class App extends LightningElement {
    @track state = {
        title: 'Welcome to Camp Innovation at TrailheaDX 2019!',
    };
}
